export const ProductData = {
  Products: [
    {
      id: 1,
      image: "./products/cologne.jpg",
      desc: "Unisex Cologne",
      ratings: "4.5/5",
      value: 0,
    },
    {
      id: 2,
      image: "./products/iwatch.jpg",
      desc: "Apple iWatch",
      ratings: "5/5",
      value: 0,
    },
    {
      id: 3,
      image: "./products/mug.jpg",
      desc: "Unique Mug",
      ratings: "3.5/5",
      value: 0,
    },
    {
      id: 4,
      image: "./products/wallet.jpg",
      desc: "Mens Wallet",
      ratings: "4/5",
      value: 0,
    },
  ],
  TotalCartItems: [
    {
      cartTotal: 0,
    },
  ],
};
